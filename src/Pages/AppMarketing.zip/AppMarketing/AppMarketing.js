import React from "react";
import "./AppMarketing.css";

const AppMarketing = () => {
  return (
    <div className="col-12 hero-container">
      <div className="col-4 content">
        <p className="subtitle">No more switching apps</p>
        <h1 className="title">
          Why download many
          <br />
          when one app can do it all?
        </h1>
        <div className="badges">
          <div className="rating-badge">
            <div>
            <span className="rating-app">4.8/5</span>
            <span>Average Rating</span>
            </div>
            <div>

            <img
              src="./AppMarketing/rating.png"
              alt="Rating stars"
              width={80}
              height={20}
              className="stars"
            />
            </div>
          </div>
          <div className="feature-badge">
            <img
              src="./AppMarketing/tik.png"
              alt="One-App badge"
              width={100}
              height={40}
            />
          </div>
          <div className="feature-badge">
            <img
              src="./AppMarketing/person.png"
              alt="Fast booking badge"
              width={100}
              height={40}
            />
          </div>
        </div>
      </div>

      <div className="col-8">
        <div className="phone-container">
          <div className="phone">
            <img
              src="./AppMarketing/iPhone_13.png"
              alt="App interface"
              // width={300}
              // height={600}
              className="phone-screen"
            />
          </div>
        </div>

        <div className="door-container">
          <img
            src="./AppMarketing/Door_and_provider.png"
            alt="People illustration"
            width={200}
            height={350}
            className="door-image"
          />
        </div>
      </div>
    </div>
  );
};

export default AppMarketing;
